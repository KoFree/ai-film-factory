import argparse
from pathlib import Path
from PIL import Image, ImageDraw

def make_assets(project_dir: Path, count: int = 6) -> None:
    assets_dir = project_dir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    for i in range(1, count + 1):
        img = Image.new("RGB", (1280, 720), color=(20 * i % 255, 30 * i % 255, 40 * i % 255))
        draw = ImageDraw.Draw(img)
        draw.text((60, 60), f"AI Film Factory\nShot {i}", fill=(255, 255, 255))
        img.save(assets_dir / f"shot_{i:03d}.png")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-dir", required=True)
    parser.add_argument("--count", type=int, default=6)
    args = parser.parse_args()
    make_assets(Path(args.project_dir), args.count)
