import argparse, subprocess
from pathlib import Path

def build_concat_file(project_dir: Path) -> Path:
    assets_dir = project_dir / "assets"
    concat_path = project_dir / "concat.txt"
    image_files = sorted([p for p in assets_dir.glob("*.png")])
    with open(concat_path, "w", encoding="utf-8") as f:
        for image in image_files:
            f.write(f"file '{image.resolve()}'\n")
            f.write("duration 2\n")
        if image_files:
            f.write(f"file '{image_files[-1].resolve()}'\n")
    return concat_path

def render_preview(project_dir: Path, output_name: str = "preview.mp4") -> Path:
    concat_path = build_concat_file(project_dir)
    output_path = project_dir / output_name
    subprocess.run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(concat_path),"-vsync","vfr","-pix_fmt","yuv420p",str(output_path)], check=True)
    return output_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-id", type=int, required=True)
    parser.add_argument("--output-root", default="output")
    args = parser.parse_args()
    output_root = Path(args.output_root)
    candidates = list(output_root.glob(f"project_{args.project_id}_*"))
    if not candidates:
        raise SystemExit("No project output folder found. Export manifest and create assets first.")
    project_dir = candidates[0]
    project_dir.joinpath("assets").mkdir(exist_ok=True)
    print(f"Rendered preview to {render_preview(project_dir)}")
