from fastapi.testclient import TestClient
from app.main import app

SCREENPLAY = """INT. EDIT SUITE - NIGHT
Mara scrubs through corrupted footage and freezes on a frame that shouldn't exist.

She leans closer. In the monitor reflection, someone is standing behind her.

INT. EDIT SUITE - CONTINUOUS
Mara spins, but the room is empty. The timeline begins to move on its own.
"""

if __name__ == "__main__":
    client = TestClient(app)
    project = client.post("/api/pipeline/projects", json={"title":"Bootstrap Demo","logline":"An editor finds impossible footage.","style_reference":"prestige supernatural thriller, moody, cinematic"}).json()
    pid = project["id"]
    client.post("/api/pipeline/intake", json={"project_id": pid, "screenplay": SCREENPLAY})
    client.post(f"/api/pipeline/{pid}/shotlist")
    client.post(f"/api/pipeline/{pid}/prompts")
    print(client.get(f"/api/pipeline/{pid}/manifest").json())
