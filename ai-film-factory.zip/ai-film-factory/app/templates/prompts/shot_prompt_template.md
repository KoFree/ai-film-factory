# Shot Prompt Template

## Positive Prompt
{{description}}. {{style_reference}}. Cinematic lighting. {{framing}} framing. {{camera_motion}}. Aspect ratio {{aspect_ratio}}.

## Negative Prompt
low resolution, extra limbs, bad anatomy, watermark, text, duplicate subject, flat lighting

## Video Direction
Generate a {{duration_seconds}}-second cinematic motion shot with grounded camera physics and subtle environmental movement.
