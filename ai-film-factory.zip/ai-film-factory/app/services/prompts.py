from typing import List
from app.schemas import PromptPacket, ShotItem

BASE_NEGATIVE = "low resolution, extra limbs, bad anatomy, watermark, text, oversaturated, flat lighting, duplicate subject"

def build_prompt_packets(shots: List[ShotItem], style_reference: str, logline: str) -> List[PromptPacket]:
    packets: List[PromptPacket] = []
    for shot in shots:
        cinematic_core = (
            f"{shot.description}. {style_reference}. Cinematic lighting, strong composition, production-ready frame, "
            f"{shot.framing}, {shot.camera_motion}, aspect ratio {shot.aspect_ratio}."
        )
        packets.append(PromptPacket(
            shot_number=shot.shot_number,
            positive_prompt=cinematic_core,
            negative_prompt=BASE_NEGATIVE,
            video_prompt=f"Create a {shot.duration_seconds}-second moving cinematic shot: {cinematic_core}",
            image_model_hint=f"Use for keyframe generation. Story context: {logline}",
            video_model_hint="Use for image-to-video or text-to-video generation with subtle physical camera motion.",
        ))
    return packets
