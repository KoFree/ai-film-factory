from app.config import settings

def provider_status() -> dict:
    return {
        "provider": settings.llm_provider,
        "configured": bool(settings.openai_api_key) if settings.llm_provider != "stub" else True,
        "note": "Stub mode uses deterministic local parsing. Replace this adapter with your preferred LLM provider.",
    }
