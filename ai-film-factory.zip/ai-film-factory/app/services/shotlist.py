from typing import List
from app.schemas import ShotItem, StoryBeat

def build_shotlist(beats: List[StoryBeat], aspect_ratio: str = "16:9", duration_seconds: int = 4) -> List[ShotItem]:
    shots: List[ShotItem] = []
    shot_number = 1
    for beat in beats:
        opening = ShotItem(
            shot_number=shot_number,
            beat_number=beat.beat_number,
            shot_type="primary",
            framing=_select_framing(beat.action),
            camera_motion=_select_motion(beat.emotional_shift),
            duration_seconds=duration_seconds,
            description=f"{beat.scene_heading}. {beat.action}",
            aspect_ratio=aspect_ratio,
        )
        shots.append(opening)
        shot_number += 1
        if len(beat.action.split()) > 18:
            shots.append(ShotItem(
                shot_number=shot_number,
                beat_number=beat.beat_number,
                shot_type="insert",
                framing="close-up",
                camera_motion="static",
                duration_seconds=max(2, duration_seconds - 1),
                description=f"Detail insert for beat {beat.beat_number}: visual emphasis on the key object, face, or gesture.",
                aspect_ratio=aspect_ratio,
            ))
            shot_number += 1
    return shots

def _select_framing(action: str) -> str:
    lowered = action.lower()
    if any(word in lowered for word in ["face", "eyes", "hand", "whisper"]):
        return "close-up"
    if any(word in lowered for word in ["runs", "crosses", "enters", "hallway"]):
        return "wide"
    return "medium"

def _select_motion(shift: str) -> str:
    return {
        "escalation": "handheld push",
        "suspense": "slow dolly",
        "revelation": "push-in",
        "progression": "locked-off",
    }.get(shift, "locked-off")
