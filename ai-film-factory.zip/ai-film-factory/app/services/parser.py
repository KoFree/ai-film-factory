import re
from typing import List
from app.schemas import StoryBeat

SCENE_HEADING_RE = re.compile(r"^(INT\.|EXT\.|INT/EXT\.|EXT/INT\.)", re.IGNORECASE)

def extract_story_beats(screenplay: str) -> List[StoryBeat]:
    lines = [line.rstrip() for line in screenplay.splitlines()]
    beats: List[StoryBeat] = []
    current_heading = "UNSPECIFIED SCENE"
    action_buffer = []
    beat_number = 1

    def flush_buffer() -> None:
        nonlocal beat_number, action_buffer
        action_text = " ".join([x.strip() for x in action_buffer if x.strip()])
        if not action_text:
            return
        emotional_shift = infer_emotional_shift(action_text)
        beats.append(StoryBeat(
            beat_number=beat_number,
            scene_heading=current_heading,
            action=action_text,
            emotional_shift=emotional_shift,
        ))
        beat_number += 1
        action_buffer = []

    for line in lines:
        if not line.strip():
            flush_buffer()
            continue
        if SCENE_HEADING_RE.match(line.strip()):
            flush_buffer()
            current_heading = line.strip()
            continue
        if line.strip().isupper() and len(line.strip().split()) <= 6:
            continue
        action_buffer.append(line.strip())

    flush_buffer()
    return beats


def infer_emotional_shift(action_text: str) -> str:
    lowered = action_text.lower()
    if any(word in lowered for word in ["panic", "scream", "runs", "terror", "fear"]):
        return "escalation"
    if any(word in lowered for word in ["whisper", "hesitates", "considers", "watches"]):
        return "suspense"
    if any(word in lowered for word in ["reveals", "discovers", "realizes"]):
        return "revelation"
    return "progression"
