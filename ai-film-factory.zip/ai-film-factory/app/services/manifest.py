import json, os
from typing import List
from app.config import settings
from app.schemas import ManifestRead, PromptPacket, ShotItem

def write_manifest(project_id: int, title: str, shotlist: List[ShotItem], prompts: List[PromptPacket]) -> ManifestRead:
    safe_title = title.lower().replace(" ", "_")
    project_dir = os.path.join(settings.output_dir, f"project_{project_id}_{safe_title}")
    os.makedirs(project_dir, exist_ok=True)
    shotlist_path = os.path.join(project_dir, "shotlist.json")
    prompts_path = os.path.join(project_dir, "prompts.json")
    with open(shotlist_path, "w", encoding="utf-8") as f:
        json.dump([item.model_dump() for item in shotlist], f, indent=2)
    with open(prompts_path, "w", encoding="utf-8") as f:
        json.dump([item.model_dump() for item in prompts], f, indent=2)
    return ManifestRead(project_id=project_id, title=title, output_paths=[shotlist_path, prompts_path], shotlist=shotlist, prompts=prompts)
