from typing import Optional
from sqlmodel import SQLModel, Field

class Project(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    title: str
    logline: str
    style_reference: str
    screenplay: str = ""
    beat_json: str = "[]"
    shotlist_json: str = "[]"
    prompts_json: str = "[]"
