from typing import List, Optional
from pydantic import BaseModel

class ProjectCreate(BaseModel):
    title: str
    logline: str
    style_reference: str

class ProjectRead(ProjectCreate):
    id: int

class IntakeRequest(BaseModel):
    project_id: int
    screenplay: str

class StoryBeat(BaseModel):
    beat_number: int
    scene_heading: str
    action: str
    emotional_shift: str

class ShotItem(BaseModel):
    shot_number: int
    beat_number: int
    shot_type: str
    framing: str
    camera_motion: str
    duration_seconds: int
    description: str
    dialogue_excerpt: Optional[str] = None
    aspect_ratio: str = "16:9"

class PromptPacket(BaseModel):
    shot_number: int
    positive_prompt: str
    negative_prompt: str
    video_prompt: str
    image_model_hint: str
    video_model_hint: str

class PipelineSummary(BaseModel):
    project_id: int
    title: str
    beat_count: int
    shot_count: int
    prompt_count: int

class ManifestRead(BaseModel):
    project_id: int
    title: str
    output_paths: List[str]
    shotlist: List[ShotItem]
    prompts: List[PromptPacket]
