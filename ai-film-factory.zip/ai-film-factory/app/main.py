from fastapi import FastAPI
from app.config import settings
from app.db import init_db
from app.routes.health import router as health_router
from app.routes.pipeline import router as pipeline_router

app = FastAPI(title=settings.app_name, version="0.1.0")

@app.on_event("startup")
def on_startup() -> None:
    init_db()

app.include_router(health_router)
app.include_router(pipeline_router)
