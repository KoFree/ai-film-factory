from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "AI Film Factory"
    env: str = "development"
    database_url: str = "sqlite:///./ai_film_factory.db"
    output_dir: str = "./output"
    llm_provider: str = "stub"
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    comfyui_base_url: str = "http://localhost:8188"
    n8n_webhook_url: str = "http://localhost:5678/webhook/ai-film-factory"
    elevenlabs_api_key: str = ""
    default_aspect_ratio: str = "16:9"
    default_duration_seconds: int = 4
    model_config = SettingsConfigDict(env_prefix="AFF_", env_file=".env", extra="ignore")

settings = Settings()
