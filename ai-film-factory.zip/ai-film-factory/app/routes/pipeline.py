import json
from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.db import get_session
from app.models import Project
from app.schemas import IntakeRequest, ManifestRead, PipelineSummary, ProjectCreate, ProjectRead, ShotItem, PromptPacket, StoryBeat
from app.services.manifest import write_manifest
from app.services.parser import extract_story_beats
from app.services.prompts import build_prompt_packets
from app.services.shotlist import build_shotlist

router = APIRouter(prefix="/api/pipeline", tags=["pipeline"])

def _beats_from_storage(raw):
    return [StoryBeat(**beat) for beat in raw]

def _shots_from_storage(raw):
    return [ShotItem(**shot) for shot in raw]

@router.post("/projects", response_model=ProjectRead)
def create_project(payload: ProjectCreate, session: Session = Depends(get_session)):
    project = Project(**payload.model_dump())
    session.add(project)
    session.commit()
    session.refresh(project)
    return project

@router.get("/projects/{project_id}", response_model=ProjectRead)
def read_project(project_id: int, session: Session = Depends(get_session)):
    project = session.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project

@router.get("/projects")
def list_projects(session: Session = Depends(get_session)):
    return session.exec(select(Project)).all()

@router.post("/intake", response_model=PipelineSummary)
def intake_screenplay(payload: IntakeRequest, session: Session = Depends(get_session)):
    project = session.get(Project, payload.project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    beats = extract_story_beats(payload.screenplay)
    project.screenplay = payload.screenplay
    project.beat_json = json.dumps([b.model_dump() for b in beats])
    session.add(project)
    session.commit()
    return PipelineSummary(project_id=project.id, title=project.title, beat_count=len(beats), shot_count=0, prompt_count=0)

@router.post("/{project_id}/shotlist", response_model=PipelineSummary)
def generate_shotlist(project_id: int, session: Session = Depends(get_session)):
    project = session.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    beats_raw = json.loads(project.beat_json or "[]")
    if not beats_raw:
        raise HTTPException(status_code=400, detail="No story beats found. Run intake first.")
    shotlist = build_shotlist(_beats_from_storage(beats_raw))
    project.shotlist_json = json.dumps([s.model_dump() for s in shotlist])
    session.add(project)
    session.commit()
    return PipelineSummary(project_id=project.id, title=project.title, beat_count=len(beats_raw), shot_count=len(shotlist), prompt_count=len(json.loads(project.prompts_json or "[]")))

@router.post("/{project_id}/prompts", response_model=PipelineSummary)
def generate_prompts(project_id: int, session: Session = Depends(get_session)):
    project = session.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    shots_raw = json.loads(project.shotlist_json or "[]")
    if not shots_raw:
        raise HTTPException(status_code=400, detail="No shotlist found. Run shotlist generation first.")
    prompts = build_prompt_packets(_shots_from_storage(shots_raw), project.style_reference, project.logline)
    project.prompts_json = json.dumps([p.model_dump() for p in prompts])
    session.add(project)
    session.commit()
    beats_raw = json.loads(project.beat_json or "[]")
    return PipelineSummary(project_id=project.id, title=project.title, beat_count=len(beats_raw), shot_count=len(shots_raw), prompt_count=len(prompts))

@router.get("/{project_id}/manifest", response_model=ManifestRead)
def export_manifest(project_id: int, session: Session = Depends(get_session)):
    project = session.get(Project, project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    shotlist = json.loads(project.shotlist_json or "[]")
    prompts = json.loads(project.prompts_json or "[]")
    if not shotlist or not prompts:
        raise HTTPException(status_code=400, detail="Shotlist and prompts must exist before export.")
    return write_manifest(project_id=project.id, title=project.title, shotlist=[ShotItem(**s) for s in shotlist], prompts=[PromptPacket(**p) for p in prompts])
