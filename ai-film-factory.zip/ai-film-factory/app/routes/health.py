from fastapi import APIRouter
from app.services.llm_client import provider_status

router = APIRouter(prefix="/health", tags=["health"])

@router.get("")
def healthcheck():
    return {"status": "ok", "llm": provider_status()}
