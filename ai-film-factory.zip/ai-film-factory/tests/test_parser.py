from app.services.parser import extract_story_beats

def test_extract_story_beats_returns_beats():
    screenplay = """INT. KITCHEN - NIGHT
Ada watches the sink drip.

She hears a whisper behind her.
"""
    beats = extract_story_beats(screenplay)
    assert len(beats) == 2
    assert beats[0].scene_heading == "INT. KITCHEN - NIGHT"
