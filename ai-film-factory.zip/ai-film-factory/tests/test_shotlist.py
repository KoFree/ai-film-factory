from app.schemas import StoryBeat
from app.services.shotlist import build_shotlist

def test_build_shotlist_creates_primary_shots():
    beats = [StoryBeat(beat_number=1, scene_heading="INT. ROOM - NIGHT", action="She whispers into the dark.", emotional_shift="suspense")]
    shots = build_shotlist(beats)
    assert len(shots) >= 1
    assert shots[0].framing in {"close-up", "medium", "wide"}
